package handler

import (
	"net/http"
	"os"
	"pheet-tutorial-gin/auth"
	"pheet-tutorial-gin/constants"
	"pheet-tutorial-gin/helper"
	"pheet-tutorial-gin/models"
	"pheet-tutorial-gin/service/products"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/gofrs/uuid"
	"golang.org/x/crypto/bcrypt"
)

type productHandler struct {
	proServ products.ProductService
}

func NewProductHandler(proServ products.ProductService) productHandler {
	return productHandler{proServ: proServ}
}

func (p productHandler) GetProducts(c *gin.Context) {
	var ctx = c.Request.Context()
	products, err := p.proServ.GetProducts(ctx)
	if err != nil {
		c.AbortWithError(http.StatusInternalServerError, err)
		return
	}

	resp := map[string]interface{}{
		"products": products,
	}

	c.JSON(http.StatusOK, resp)
}

func (p productHandler) Create(c *gin.Context) {
	var ctx = c.Request.Context()
	var err error
	var imgPath string
	var proReq = new(models.Products)
	var time = helper.NewTimestampFromTime(time.Now())

	/* Binding Data && Validation*/
	if err = c.ShouldBind(proReq); err != nil {
		c.JSON(http.StatusInternalServerError, err.Error())
		return
	}
	imgFile, err := c.FormFile("image")
	if err != nil {
		c.JSON(http.StatusUnprocessableEntity, gin.H{
			"image": "must be required",
		})
		return
	}
	if err = proReq.ValidationStruct(); err != nil {
		c.JSON(http.StatusUnprocessableEntity, gin.H{
			"error:": err.Error(),
		})
		return
	}

	/* Image Management */
	if imgFile != nil {
		imgPath = "./uploads/products/" + imgFile.Filename
		err = c.SaveUploadedFile(imgFile, imgPath)
		if err != nil {
			c.JSON(http.StatusInternalServerError, err.Error())
			return
		}
	}

	/* Setting id, time and imagePath */
	proReq.NewUUID()
	proReq.SetCreatedAt(&time)
	proReq.SetUpdatedAt(&time)
	proReq.SetImagePath(imgPath)

	/* Sending Create */
	err = p.proServ.Create(ctx, proReq)
	if err != nil {
		if strings.Contains(err.Error(), constants.ERROR_PRODUCTNAME_WAS_DUPLICATE) {
			c.JSON(http.StatusUnprocessableEntity, gin.H{
				"error:": constants.ERROR_PRODUCTNAME_WAS_DUPLICATE,
			})
			return
		}
		c.JSON(http.StatusInternalServerError, err.Error())
		return
	}

	resp := map[string]interface{}{
		"message": "successful",
		"id": proReq.Id,
	}

	c.JSON(http.StatusOK, resp)
}

func (p productHandler) Update(c *gin.Context) {
	var ctx = c.Request.Context()
	var err error
	var imgPath string
	var newPro = new(models.Products)
	var time = helper.NewTimestampFromTime(time.Now())
	var proId = uuid.FromStringOrNil(c.Param("product_id"))

	/* Binding Data*/
	err = c.ShouldBind(newPro)
	if err != nil {
		c.JSON(http.StatusInternalServerError, err.Error())
		return
	}
	imgFile, _ := c.FormFile("image")

	/* Fetch Existing Product For Merge Data */
	existPro, err := p.proServ.GetProduct(&proId)
	if err != nil {
		c.JSON(http.StatusInternalServerError, err.Error())
		return
	}

	/* Image Management */
	if imgFile != nil {
		/* Delete Existing Image File */
		err := os.Remove(existPro.Image)
		if err != nil {
			c.JSON(http.StatusInternalServerError, err.Error())
			return
		}
		/* Save New Image File && Assign Image Path*/
		imgPath = "./uploads/products/" + imgFile.Filename
		err = c.SaveUploadedFile(imgFile, imgPath)
		if err != nil {
			c.JSON(http.StatusInternalServerError, err.Error())
			return
		}
		newPro.SetImagePath(imgPath)
	} else {
		newPro.SetImagePath(existPro.Image)
	}

	/* Setting id, time and imagePath */
	newPro.Id = existPro.Id       // assign existing id
	newPro.MergeProduct(existPro) //merge with existing data
	newPro.UpdatedAt = &time      // seting updated_at

	/* Sending Update */
	err = p.proServ.Update(ctx, newPro, &proId)
	if err != nil {
		if strings.Contains(err.Error(), constants.ERROR_PRODUCTNAME_WAS_DUPLICATE) {
			c.JSON(http.StatusUnprocessableEntity, gin.H{
				"error:": constants.ERROR_PRODUCTNAME_WAS_DUPLICATE,
			})
			return
		}
		c.JSON(http.StatusInternalServerError, err.Error())
		return
	}

	resp := map[string]interface{}{
		"message": "successful",
	}

	c.JSON(http.StatusOK, resp)
}

func (p productHandler) GetProductById(c *gin.Context) {
	var id = uuid.FromStringOrNil(c.Param("product_id"))

	product, err := p.proServ.GetProduct(&id)
	if err != nil {
		c.AbortWithError(http.StatusInternalServerError, err)
	}

	if product == nil {
		c.JSON(http.StatusNotFound, gin.H{"error": err.Error()})
	}

	resp := map[string]interface{}{
		"product": product,
	}

	c.JSON(http.StatusOK, resp)
}

func (h productHandler) Login(c *gin.Context) {
	var request = models.User{}

	err := c.ShouldBindJSON(&request)
	if err != nil {
		c.AbortWithError(http.StatusUnprocessableEntity, err)
	}

	if request.Username == "" || request.Password == "" {
		c.AbortWithError(http.StatusUnprocessableEntity, err)
	}

	user, err := h.proServ.GetUser(request.Username)
	if err != nil {
		c.AbortWithError(http.StatusNotFound, err)
	}

	err = bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(request.Password))
	if err != nil {
		c.AbortWithError(http.StatusNotFound, err)
	}

	tokenz := auth.AccessToken(os.Getenv("SIGN"))

	resp := map[string]interface{}{
		"message": "Login-success",
		"jwt":     tokenz,
	}

	c.JSON(http.StatusOK, resp)
}

func (h productHandler) SignUp(c *gin.Context) {
	var ctx = c.Request.Context()
	var request = models.User{}
	var time = helper.NewTimestampFromTime(time.Now())
	err := c.ShouldBindJSON(&request)
	if err != nil {
		c.AbortWithError(http.StatusUnprocessableEntity, err)
	}

	if request.Username == "" || request.Password == "" {
		c.AbortWithError(http.StatusBadRequest, err)
	}

	password, err := bcrypt.GenerateFromPassword([]byte(request.Password), 10)
	if err != nil {
		c.AbortWithError(http.StatusUnprocessableEntity, err)
	}
	request.Password = string(password)
	request.NewUUID()
	request.SetCreatedAt(&time)
	request.SetUpdatedAt(&time)

	if err = h.proServ.SignUp(ctx, &request); err != nil {
		if strings.Contains(err.Error(), constants.ERROR_USERNAME_WAS_DUPLICATE) {
			c.JSON(http.StatusConflict, constants.ERROR_USERNAME_WAS_DUPLICATE)
			return
		}
		c.AbortWithError(http.StatusInternalServerError, err)
		return
	}

	resp := map[string]interface{}{
		"message": "SignUp-Success",
	}

	c.JSON(http.StatusOK, resp)
}

func (h productHandler) DeleteProduct(c *gin.Context) {
	var ctx = c.Request.Context()
	var id = uuid.FromStringOrNil(c.Param("product_id"))

	/* Fetch ImagePath and Delete File*/
	product, err := h.proServ.GetProduct(&id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, err.Error())
		return
	}
	if err = os.RemoveAll(product.Image); err != nil {
		c.JSON(http.StatusUnprocessableEntity, err.Error())
		return
	}

	if err = h.proServ.Delete(ctx, &id); err != nil {
		c.JSON(http.StatusInternalServerError, err.Error())
		return
	}

	resp := map[string]interface{}{
		"Delete-Product": "Success.",
	}

	c.JSON(http.StatusOK, resp)
}
