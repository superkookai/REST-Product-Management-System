package main

import (
	"log"
	"net/http"
	"os"

	"pheet-tutorial-gin/auth"
	"pheet-tutorial-gin/helper"
	"pheet-tutorial-gin/middleware"
	"pheet-tutorial-gin/route"
	handler "pheet-tutorial-gin/service/products/http"
	"pheet-tutorial-gin/service/products/repository"
	"pheet-tutorial-gin/service/products/service"

	"github.com/gin-gonic/gin"
	"github.com/jmoiron/sqlx"
	"github.com/joho/godotenv"
	_ "github.com/lib/pq"
)

var (
	PSQL_DATABASE_URL = helper.GetENV("PSQL_DATABASE_URL", "")
)

func main() {
	var err error
	err = godotenv.Load(".env") /*Load Env*/
	if err != nil {
		log.Printf("please consider environment variable: %s", err)
	}

	psqlDB, err := sqlx.Open("postgres", os.Getenv("PSQL_DATABASE_URL"))
	if err != nil {
		panic(err)
	}

	err = psqlDB.Ping()
	if err != nil {
		log.Println(err)
	}

	productRepo := repository.NewProductRepository(psqlDB)
	productServ := service.NewProductService(productRepo)
	productHand := handler.NewProductHandler(productServ)

	r := gin.Default()
	
	r.Use(middleware.CORSMiddleware())
	
	r.GET("/", func(c *gin.Context) {
		c.JSON(http.StatusOK, "Bizcuitware Web!!!")
	})
	r.POST("/register", productHand.SignUp)
	r.POST("/login", productHand.Login)
	r.GET("/product/list", productHand.GetProducts)
	r.GET("/product/:product_id", productHand.GetProductById)
	r.Static("/uploads", "./uploads")

	routeGroup := r.Group("/product", auth.Protect([]byte(os.Getenv("SIGN"))), middleware.CORSMiddleware())
	route := route.NewRoute(routeGroup)
	route.RegisterProduct(productHand)

	r.Run(os.Getenv("PORT"))

}
