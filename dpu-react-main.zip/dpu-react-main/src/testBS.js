export default function TestBS(){
    return (
        <div>
            <div className="bg-danger text-white">
                Alert!! Under 18 prohibit!!            
            </div>
            <p className="bg-success text-white text-center">You win!!</p>
        </div>

    );
}