package products

import (
	"context"
	"pheet-tutorial-gin/models"

	"github.com/gofrs/uuid"
)

type ProductService interface {
	GetProducts(ctx context.Context) ([]*models.Products, error)
	GetProduct(id *uuid.UUID) (*models.Products, error)
	GetProductByType(coffType string) ([]*models.Products, error)
	GetUser(username string) (*models.User, error)
	Create(ctx context.Context, product *models.Products) error
	SignUp(ctx context.Context, user *models.User) error
	Update(ctx context.Context, product *models.Products, id *uuid.UUID) error 
	Delete(ctx context.Context, id *uuid.UUID) error
}
