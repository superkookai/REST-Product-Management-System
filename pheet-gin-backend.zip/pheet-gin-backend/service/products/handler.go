package products

import (
	"github.com/gin-gonic/gin"
)

type ProductHandler interface {
	Create(c *gin.Context)
	GetProducts(c *gin.Context)
	GetProductById(c *gin.Context)
	Update(c *gin.Context)
	Login(c *gin.Context)
	SignUp(c *gin.Context)
	DeleteProduct(c *gin.Context)
}