package service

import (
	"context"
	"pheet-tutorial-gin/models"
	"pheet-tutorial-gin/service/products"

	"github.com/gofrs/uuid"
)

type productService struct {
	proRepo products.ProductRepository
}

func NewProductService(proRepo products.ProductRepository) productService {
	return productService{proRepo: proRepo}
}

func (r productService) GetProducts(ctx context.Context) ([]*models.Products, error) {
	return r.proRepo.FetchAll(ctx)
}

func (r productService) GetProduct(id *uuid.UUID) (*models.Products, error) {
	return r.proRepo.FetchById(id)
}

func (r productService) GetUser(username string) (*models.User, error) {
	return r.proRepo.FetchUser(username)
}

func (r productService) GetProductByType(coffType string) ([]*models.Products, error) {
	return r.proRepo.FetchByType(coffType)
}

func (r productService) Create(ctx context.Context, product *models.Products) error {
	return r.proRepo.Create(ctx, product)
}

func (r productService) SignUp(ctx context.Context, user *models.User) error {
	return r.proRepo.SignUp(ctx, user)
}

func (r productService) Update(ctx context.Context, product *models.Products, id *uuid.UUID) error {
	return r.proRepo.Update(ctx, product, id)
}

func (r productService) Delete(ctx context.Context, id *uuid.UUID) error {
	return r.proRepo.Delete(ctx, id)
}
