package route

import (
	"pheet-tutorial-gin/service/products"

	"github.com/gin-gonic/gin"
)

type Route struct {
	e *gin.RouterGroup
}

func NewRoute(e *gin.RouterGroup) Route {
	return Route{e: e}
}

func (r Route) RegisterProduct(handler products.ProductHandler) {
	r.e.POST("", handler.Create)
	r.e.PUT("/:product_id", handler.Update)
	r.e.DELETE("/:product_id", handler.DeleteProduct)
}
