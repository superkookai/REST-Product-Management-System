package products

import (
	"context"
	"pheet-tutorial-gin/models"

	"github.com/gofrs/uuid"
)

type ProductRepository interface {
	FetchAll(ctx context.Context) ([]*models.Products, error)
	FetchById(id *uuid.UUID)(*models.Products, error)
	FetchByType(coffType string) ([]*models.Products, error)
	FetchUser(username string)(*models.User, error)
	Create(ctx context.Context, product *models.Products) error
	SignUp(ctx context.Context, user *models.User) error
	Update(ctx context.Context, product *models.Products, id *uuid.UUID) error 
	Delete(ctx context.Context, id *uuid.UUID) error
}